#' add
#'
#' Takes in a numeric list and adds up all the values in the list
#'
#' @name add
#' @param x: numeric list
#' @export


add <- function(x){
  sum(x)
}
