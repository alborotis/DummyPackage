expect_equal(add(c(1,2,3)), 6)
